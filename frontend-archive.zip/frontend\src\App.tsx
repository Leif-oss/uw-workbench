import { Navigate, Route, Routes } from "react-router-dom";
import AppLayout from "./layout/AppLayout";
import DashboardPage from "./pages/DashboardPage";
import AgenciesPage from "./pages/AgenciesPage";
import EmployeesPage from "./pages/EmployeesPage";
import OfficesPage from "./pages/OfficesPage";
import WorkbenchPage from "./pages/WorkbenchPage";
import TasksPage from "./pages/TasksPage";
import AdminPage from "./pages/AdminPage";
import { AdminSetupPage } from "./pages/AdminSetupPage";
import CrmHomePage from "./pages/CrmHomePage";
import CrmUnderwritersPage from "./pages/CrmUnderwritersPage";
import CrmReportsPage from "./pages/CrmReportsPage";
import CrmOfficeDetailPage from "./pages/CrmOfficeDetailPage";
import CrmAgencyDetailPage from "./pages/CrmAgencyDetailPage";
import ReinsuranceCalculatorPage from "./pages/ReinsuranceCalculatorPage";
import DocumentScrubberPage from "./pages/DocumentScrubberPage";
import AiAssistantPage from "./pages/AiAssistantPage";
import LoginPage from "./pages/LoginPage";
import ForgotPasswordPage from "./pages/ForgotPasswordPage";
import ResetPasswordPage from "./pages/ResetPasswordPage";
import SetPasswordPage from "./pages/SetPasswordPage";

function ProtectedLayout() {
  const isAuthenticated = !!localStorage.getItem("auth_token");
  const location = window.location.pathname;
  
  // TEMPORARY: Allow access to /admin without authentication for initial setup
  // TODO: Remove this after creating first admin user
  const TEMP_ALLOW_ADMIN_WITHOUT_AUTH = true; // Set to false after setup
  
  if (!isAuthenticated && !(TEMP_ALLOW_ADMIN_WITHOUT_AUTH && location.startsWith("/admin"))) {
    return <Navigate to="/login" replace />;
  }
  
  return <AppLayout />;
}

function AdminRoute({ children }: { children: React.ReactElement }) {
  const isAdmin = localStorage.getItem("is_admin") === "true";
  
  // TEMPORARY: Allow access without admin check for initial setup
  // TODO: Remove this after creating first admin user
  const TEMP_ALLOW_ADMIN_WITHOUT_AUTH = true; // Set to false after setup
  
  if (!isAdmin && !TEMP_ALLOW_ADMIN_WITHOUT_AUTH) {
    return <Navigate to="/dashboard" replace />;
  }
  
  return children;
}

function App() {
  // TEMPORARY: Allow /admin without authentication for initial setup
  // TODO: Move /admin back inside ProtectedLayout after creating first admin
  const TEMP_ALLOW_ADMIN_WITHOUT_AUTH = true; // Set to false after setup
  
  return (
    <Routes>
      <Route path="/login" element={<LoginPage />} />
      <Route path="/forgot-password" element={<ForgotPasswordPage />} />
      <Route path="/reset-password" element={<ResetPasswordPage />} />
      <Route path="/set-password" element={<SetPasswordPage />} />
      <Route element={<ProtectedLayout />}>
        <Route index element={<DashboardPage />} />
        <Route path="/dashboard" element={<DashboardPage />} />
        <Route path="/crm" element={<Navigate to="/crm/offices" replace />} />
        <Route path="/crm/offices" element={<CrmHomePage />} />
        <Route path="/crm/offices/:officeId" element={<CrmOfficeDetailPage />} />
        <Route path="/crm/agencies" element={<AgenciesPage />} />
        <Route path="/crm/agencies/:agencyId" element={<CrmAgencyDetailPage />} />
        <Route path="/crm/underwriters" element={<CrmUnderwritersPage />} />
        <Route path="/crm/employees" element={<EmployeesPage />} />
        <Route path="/crm/reports" element={<CrmReportsPage />} />
        <Route path="/agencies" element={<AgenciesPage />} />
        <Route path="/employees" element={<Navigate to="/crm/employees" replace />} />
        <Route path="/offices" element={<OfficesPage />} />
        <Route path="/workbench" element={<WorkbenchPage />} />
        <Route path="/workbench/reinsurance-calculator" element={<ReinsuranceCalculatorPage />} />
        <Route path="/workbench/document-scrubber" element={<DocumentScrubberPage />} />
        <Route path="/workbench/ai-assistant" element={<AiAssistantPage />} />
        <Route path="/tasks" element={<TasksPage />} />
        <Route 
          path="/admin" 
          element={
            <AdminRoute>
              <AdminPage />
            </AdminRoute>
          } 
        />
        <Route path="*" element={<Navigate to="/dashboard" replace />} />
      </Route>
      <Route path="*" element={<Navigate to="/login" replace />} />
    </Routes>
  );
}

export default App;
